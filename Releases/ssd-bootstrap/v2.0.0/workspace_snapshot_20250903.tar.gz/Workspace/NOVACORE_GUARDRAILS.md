# NovaCore Guardrails Documentation

**Version:** 1.0  
**Last Updated:** 2025-09-01  
**Author:** yasseraly@iMac  

---

## Purpose
This document defines the immutable guardrails protecting the NovaCore Workspace (`/Volumes/Workspace`).  
It ensures that no session, agent, or human operator can modify core files without first understanding their role, dependencies, and impact.  

---

## Locked & Protected Files

| File | Purpose | Dependencies | Rules for Change |
|------|----------|--------------|------------------|
| `.NOVACORE_OK` | Sentinel proving that preflight checks passed | Used by `novaguard`, `ncgo` | Never delete. If missing, rerun `novaguard`. |
| `README-START-HERE.md` | Human-facing instructions for starting sessions safely | Referenced in onboarding | May be updated only to clarify instructions. Never remove core sections. |
| `manifest.json` | Primary integrity manifest (append-only) | Updated by `nova_manifest_update` | Never edit manually. Use tooling only. |
| `nova.core.manifest.json` | Shadow manifest for redundancy and cross-checks | Updated by `nova_manifest_update` | Same rules as `manifest.json`. |
| `~/Library/LaunchAgents/com.novacore.ownership.plist` | Auto-enforces ownership on mount | Depends on `/usr/local/bin/novaguard_helper.sh` | Do not rename. Update only via approved scripts. |
| `/usr/local/bin/novaguard` | Preflight checker (guardrails) | Calls system utilities (`diskutil`, `df`) | Changes must keep all invariants intact. |
| `/usr/local/bin/nova_manifest_update` | Manifest updater | Depends on Python + SHA-256 logic | Modify only to extend functionality, not to bypass checks. |

---

## Recovery Strategy

1. **If volume fails preflight:**  
   - Run `novaguard` directly.  
   - Fix reported invariant (ownership, encryption, filesystem).  

2. **If manifests are corrupted or missing:**  
   - Restore last good copy from backup.  
   - Re-run `nova_manifest_update` to regenerate hashes.  

3. **If LaunchAgent fails:**  
   - Check logs at `/tmp/novaguard_agent.log`.  
   - Re-load with:  
     ```bash
     launchctl unload ~/Library/LaunchAgents/com.novacore.ownership.plist
     launchctl load ~/Library/LaunchAgents/com.novacore.ownership.plist
     ```

---

## Contribution Rules

- **Append-only:** Manifests and logs must never be edited in place.  
- **Cryptographic sealing:** All baseline files must be hashed and recorded in the manifest.  
- **Transparency:** Every new file added must be appended here with:  
  - Purpose  
  - Dependencies  
  - Safe rules for change  

---

## Notes

- These guardrails follow **state-of-the-art FAANG practices**:  
  - Immutable manifests (Google SLSA style).  
  - Automated ownership enforcement (Apple launchd integration).  
  - Sentinel verification (AWS-style preflight blockers).  
- Always run `ncgo` before starting work.  
- If in doubt: **STOP, check this file, then proceed.**

---
