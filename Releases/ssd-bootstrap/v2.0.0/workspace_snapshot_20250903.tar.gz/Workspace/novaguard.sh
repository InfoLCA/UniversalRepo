#!/bin/bash
set -euo pipefail

VOLUME="/Volumes/Workspace"
LOG="$VOLUME/.nova/logs/novaguard.log"
SENTINEL="$VOLUME/.NOVACORE_OK"
MIN_FREE_GB=10

# Colors
RED="$(tput setaf 1)"
GREEN="$(tput setaf 2)"
RESET="$(tput sgr0)"

check_fail() {
  echo "${RED}✘ $1${RESET}" | tee -a "$LOG"
  exit 1
}

check_ok() {
  echo "${GREEN}✔ $1${RESET}" | tee -a "$LOG"
}

echo "---- $(date) ----" >> "$LOG"

# 1. Volume exists
[[ -d "$VOLUME" ]] || check_fail "Volume $VOLUME not mounted."

# 2. Owners enabled
diskutil info "$VOLUME" | grep -q "Owners:.*Enabled" || check_fail "Owners not enabled."

# 3. Filesystem is APFS case-sensitive, encrypted
diskutil info "$VOLUME" | grep -q "File System Personality:.*Case-sensitive APFS" || check_fail "Not case-sensitive APFS."
diskutil info "$VOLUME" | egrep -q "Encrypted:[[:space:]]*Yes|FileVault:[[:space:]]*Yes" || check_fail "Not encrypted."

# 4. Free space
FREE_GB=$(df -g "$VOLUME" | tail -1 | awk '{print $4}')
(( FREE_GB < MIN_FREE_GB )) && check_fail "Free space too low: ${FREE_GB}GB (need >= ${MIN_FREE_GB}GB)"

check_ok "Volume $VOLUME is secure and ready."

# ---[ Cosign verification: added 2025-09-02 ]---
if command -v cosign >/dev/null 2>&1; then
  echo "[novaguard] Verifying signed manifests (cosign bundle + identity pinning)…"
  COSIGN_EXPERIMENTAL=1 cosign verify-blob \
    --bundle /Volumes/Workspace/.nova/manifests/manifest.json.bundle \
    --certificate-identity-regexp 'info@legalcaseallies.com' \
    --certificate-oidc-issuer https://github.com/login/oauth \
    /Volumes/Workspace/.nova/manifests/manifest.json || { echo "[ERROR] manifest.json signature verification failed"; exit 1; }

  COSIGN_EXPERIMENTAL=1 cosign verify-blob \
    --bundle /Volumes/Workspace/.nova/manifests/nova.core.manifest.json.bundle \
    --certificate-identity-regexp 'info@legalcaseallies.com' \
    --certificate-oidc-issuer https://github.com/login/oauth \
    /Volumes/Workspace/.nova/manifests/nova.core.manifest.json || { echo "[ERROR] nova.core.manifest.json signature verification failed"; exit 1; }

  echo "[novaguard] Signatures verified ✓"
else
  echo "[WARN] cosign not installed; skipping signature verification"
fi
# ---[ end cosign block ]---

# ---[ Freshness check: last_verified vs sentinel mtime (>10m warns) ]---
if command -v jq >/dev/null 2>&1; then
  SENTINEL="${SENTINEL:-/Volumes/Workspace/.NOVACORE_OK}"
  # stat -f %m is BSD/macOS; fall back to gstat if available
  if command -v stat >/dev/null 2>&1; then
    SENT_TS=$(stat -f %m "$SENTINEL" 2>/dev/null || true)
  fi
  for f in /Volumes/Workspace/.nova/manifests/manifest.json /Volumes/Workspace/.nova/manifests/nova.core.manifest.json; do
    LV=$(jq -r '.integrity.last_verified // empty' "$f")
    if [ -n "$LV" ] && [ -n "$SENT_TS" ]; then
      # LV format: "YYYY-MM-DD hh:mm:ss AM/PM -04:00"
      LV_TS=$(python3 - "$LV" <<'PY'
import sys, datetime
s = sys.argv[1]
dt = datetime.datetime.strptime(s, "%Y-%m-%d %I:%M:%S %p %z")
print(int(dt.timestamp()))
PY
)
      if [ -n "$LV_TS" ] && [ $(( SENT_TS - LV_TS )) -gt 600 ]; then
        echo "[WARN] $f last_verified older than sentinel by >10m"
      fi
    else
      echo "[WARN] $f missing integrity.last_verified or sentinel mtime"
    fi
  done
fi
# ---[ end freshness check ]---

# ---[ moved: update sentinel after successful verification ]---
echo "LAST_OK: $(date)" > "$SENTINEL"ncheck_ok