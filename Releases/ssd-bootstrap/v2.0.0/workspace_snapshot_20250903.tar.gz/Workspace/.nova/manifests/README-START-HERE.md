# 🚀 NovaCore Secure Workspace — START HERE

This SSD volume **/Volumes/Workspace** is the single source of truth for NovaCore development.  
It has been hardened to **state-of-the-art engineering standards** (FAANG+ level) to guarantee determinism, security, and zero accidental drift.

---

## ✅ Guardrails Always Enforced

1. **Ownership**  
   - Volume owners: **Enabled**  
   - Checked + auto-fixed on every mount by a LaunchAgent.  

2. **Filesystem**  
   - APFS (Case-sensitive, Encrypted).  
   - Encryption password stored in macOS Keychain (`Workspace`).  

3. **Preflight Checks**  
   - Run with:  
     ```bash
     ncgo
     ```  
   - This executes **NovaGuard**:  
     - Ensures mountpoint exists.  
     - Confirms Owners: Enabled.  
     - Confirms Case-sensitive APFS.  
     - Confirms Encrypted: Yes.  
     - Ensures ≥10GB free.  
     - Updates sentinel + manifests.

4. **Sentinel File**  
   - `/Volumes/Workspace/.NOVACORE_OK` updated automatically.  
   - Must always exist; if missing → stop work immediately.

5. **Manifests**  
   - `manifest.json` and `nova.core.manifest.json` track file integrity.  
   - Updated automatically on each `ncgo` run.  
   - Append-only, never modify old entries.  

---

## 🟢 What “Good” Looks Like

Sample output from `ncgo`:

NovaCore Preflight (guardrails on)
✅ Volume present: /Volumes/Workspace
✅ Ownership: Enabled
✅ Filesystem: Case-sensitive APFS
✅ Encryption: Enabled
✅ Free space: 1800+GB (>= 10GB)

NovaCore Preflight Summary
• Volume UUID:    
• Filesystem:     Case-sensitive APFS
• Ownership:      Enabled
• Encryption:     Yes
• Size/Used:      
✅ All invariants satisfied. Ready.

---

## 🔴 If You See Red

- **❌ Owners not enabled** → re-run `ncgo`; if persists, check `/tmp/novaguard_agent.log`.  
- **❌ Not encrypted** → stop immediately; reformat required.  
- **❌ Free space too low** → free disk space before continuing.  
- **❌ Sentinel missing** → run `ncgo` to regenerate.  

Logs:  
```bash
cat /tmp/novaguard_agent.log

📌 Rules of Engagement
	•	Always start work by running ncgo.
	•	Never bypass NovaGuard.
	•	Never delete or overwrite manifests.
	•	If any invariant fails, fix it before making changes.
	•	Every new file must be appended to the manifest with its SHA-256.
	•	Optionally: sign manifests with Cosign/GPG for cryptographic attestation.
