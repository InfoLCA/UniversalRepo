# 🚀 NovaCore Secure Workspace — START HERE

This SSD volume **/Volumes/Workspace** is the single, authoritative workspace for NovaCore development.  
It is hardened to **state-of-the-art engineering standards** (FAANG-level) to guarantee determinism, security, and zero accidental drift.

---

## ✅ Guardrails Always Enforced

1) **Ownership**
   - Volume owners: **Enabled** at all times (auto-fixed by LaunchAgent on mount).
   - Failure policy: **fail-closed** (no work proceeds if owners are off).
   - Audit: Ownership state recorded in NovaGuard logs on every preflight.

2) **Filesystem**
   - Format: **APFS, Encrypted, Case-Sensitive** (project policy).
   - Key management: macOS Keychain item **“Workspace”**.
   - Failure policy: if not APFS/Encrypted/Case-Sensitive → **stop** (no work; re-provision required).

3) **Preflight Checks (NovaGuard `ncgo`)**
   - Run **before any work**; run again after notable changes.
   - Invariants verified on each run:
     - Mountpoint exists and is healthy.
     - Owners **Enabled**.
     - Filesystem: **APFS / Encrypted / Case-Sensitive** (as required).
     - Free space **≥ 10 GB**.
     - Sentinel refreshed; manifests updated/verified.
   - Extended checks (SOTA additions):
     - Drift detection (recompute **sha256** + size for tracked files).
     - Dual-ledger consistency (human vs machine manifests).
     - Optional Cosign OIDC verification if signatures are enabled.

4) **Sentinel**
   - Path: `/Volumes/Workspace/.NOVACORE_OK` (auto-maintained).
   - If missing/corrupt → **stop work** and run `ncgo` to recover.
   - The timestamp in the sentinel reflects last successful preflight.

5) **Manifests (Dual-Track)**
   - **Human manifest:** `/Volumes/Workspace/MANIFEST.json` (readable, Git-tracked, **append-only**).
   - **Machine ledger:** `/Volumes/Workspace/.nova.core.manifest.json` (tool-managed, **do not edit**).
   - Every tracked file entry includes: `path`, `type`, `created`, `size_bytes`, `sha256`, `last_verified`.
   - Policy: **never edit existing entries**; always **append** new records.
   - SOTA option: **Cosign keyless** signatures for the human manifest → store at `/Volumes/Workspace/.signatures/manifest.sig` for tamper evidence.

---

## 🟢 Good State (example `ncgo` summary)

NovaCore Preflight
✅ Volume present: /Volumes/Workspace
✅ Ownership: Enabled
✅ Filesystem: APFS (Encrypted, Case-Sensitive)
✅ Free space: OK (≥ 10GB)
✅ Sentinel: refreshed
✅ Manifests: verified (hashes match; dual-ledger consistent)

Ready: all guardrails satisfied.

---

## 🔴 Fail-Closed Playbook (what to do if anything is red)

- **Ownership disabled** → Unmount/remount; the mount helper re-enables owners. Re-run `ncgo`.  
- **Filesystem/encryption mismatch** → Stop; re-provision volume to policy.  
- **Free space < 10 GB** → Free space; re-run `ncgo`.  
- **Sentinel missing** → `ncgo` regenerates; if it cannot, stop and review logs.  
- **Manifest drift (size/hash mismatch)** → Run `ncgo verify`; if drift persists and change is legitimate, **append** a new manifest record; if not, revert the file.  
- **Cosign verify fails (if enabled)** → Treat as tamper; halt and investigate provenance.

---

## 📒 Explanation & Operating Discipline

- **Single Source of Truth:** Only `/Volumes/Workspace` is trusted for NovaCore.  
- **Start-of-Day Ritual:** Always begin with `ncgo` (preflight).  
- **Append-Only Evidence:** If it isn’t in **MANIFEST.json**, it **doesn’t exist**. Never rewrite history; **append**.  
- **Dual-Ledger Integrity:** Human manifest and machine ledger must match. Any divergence → **stop** and reconcile.  
- **Continuous Verification:** Run `ncgo verify` before disconnecting the SSD and after substantial edits.  
- **Cryptographic Attestation (optional but recommended):** Enable **Cosign OIDC** signing on manifest writes; keep signatures in `.signatures/`.  
- **Auditability:** All checks log to `/tmp/novaguard_agent.log` and `/Volumes/Workspace/.logs/novaguard_checks.log` (rotated).  
- **Fail-Closed Mindset:** Any invariant violation blocks work until resolved; no exceptions.

---

## 📂 Paths & Files (quick reference)

- **Sentinel:** `/Volumes/Workspace/.NOVACORE_OK`  
- **Human manifest (append-only):** `/Volumes/Workspace/MANIFEST.json`  
- **Machine ledger (tool-managed):** `/Volumes/Workspace/.nova.core.manifest.json`  
- **Logs:** `/tmp/novaguard_agent.log`, `/Volumes/Workspace/.logs/novaguard_checks.log`  
- **Signatures (optional):** `/Volumes/Workspace/.signatures/manifest.sig`

---

# 🔒 NovaCore Security Hardening Plan (Final Pre–Folder Tree)

These five steps extend the baseline guardrails to FAANG++ level.

---

### Step 1 – Immutable Baseline (APFS + DMG)

Goal: Prevent silent tampering of guard scripts and sentinel. Equivalent to dm-verity at Google scale.  
- Stage key files under `~/NovaCoreBaseline/` (novaguard, manifest updater, sentinel, README, manifests).  
- Create signed, read-only DMG:
  ```bash
  hdiutil create -volname NovaCoreBaseline -srcfolder ~/NovaCoreBaseline -ov -fs APFS -encryption AES-256 -stdinpass ~/NovaCoreBaseline.dmg

	•	Mount with:

hdiutil attach ~/NovaCoreBaseline.dmg -readonly

Step 2 – Cryptographic Seal (Cosign + Rekor)

Goal: Add verifiable signatures + public transparency log.
	•	Install cosign: brew install cosign.
	•	Sign manifest:

COSIGN_EXPERIMENTAL=1 cosign sign-blob --keyless /Volumes/Workspace/nova.core.manifest.json > manifest.sig

	•	Verify signature with cosign.

⸻

Step 3 – Attestation-Lite

Goal: NovaGuard refuses to proceed if manifest not verified.
	•	Embed cosign verification inside /usr/local/bin/novaguard.
	•	Any failed signature check blocks with error “Manifest not verified”.

⸻

Step 4 – SBOM + Provenance

Goal: Track supply chain of guard binaries/scripts. Matches FAANG SLSA.
	•	Install Syft: brew install syft.
	•	Generate SBOM:

syft dir:/usr/local/bin -o json > /Volumes/Workspace/nova.sbom.json

	•	Hash + sign SBOM with cosign.
	•	Append SBOM entry into manifests with sha256 + size.

⸻

Step 5 – Real-Time Monitoring (osquery + Watchman)

Goal: Tamper detection at runtime.
	•	Install osquery + Watchman.
	•	osquery pack runs hourly hash scan under /Volumes/Workspace.
	•	Watchman triggers logs on every live change:

watchman watch /Volumes/Workspace
watchman -- trigger /Volumes/Workspace logchange -- '*' -- sh -c 'echo "[WATCHMAN] Change detected: $@" >> /tmp/workspace_watch.log'

📊 Progress Tracking
	•	✅ Step 1: Immutable DMG baseline sealed.
	•	✅ Step 2: Cosign cryptographic seal verified.
	•	✅ Step 3: NovaGuard attestation enforced.
	•	✅ Step 4: SBOM supply chain recorded + signed.
	•	✅ Step 5: Real-time monitoring active (osquery + Watchman).

End state:
