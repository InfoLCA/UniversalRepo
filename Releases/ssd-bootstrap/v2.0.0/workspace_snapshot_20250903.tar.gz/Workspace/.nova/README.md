# NovaCore internal area
