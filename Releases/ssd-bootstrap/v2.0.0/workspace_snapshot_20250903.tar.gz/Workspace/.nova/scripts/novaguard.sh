#!/bin/bash
set -euo pipefail

VOLUME="/Volumes/Workspace"
LOG="$VOLUME/novaguard.log"
SENTINEL="$VOLUME/.NOVACORE_OK"
MIN_FREE_GB=10

# Colors
RED="$(tput setaf 1)"
GREEN="$(tput setaf 2)"
RESET="$(tput sgr0)"

check_fail() {
  echo "${RED}✘ $1${RESET}" | tee -a "$LOG"
  exit 1
}

check_ok() {
  echo "${GREEN}✔ $1${RESET}" | tee -a "$LOG"
}

echo "---- $(date) ----" >> "$LOG"

# 1. Volume exists
[[ -d "$VOLUME" ]] || check_fail "Volume $VOLUME not mounted."

# 2. Owners enabled
diskutil info "$VOLUME" | grep -q "Owners:.*Enabled" || check_fail "Owners not enabled."

# 3. Filesystem is APFS case-sensitive, encrypted
diskutil info "$VOLUME" | grep -q "File System Personality:.*Case-sensitive APFS" || check_fail "Not case-sensitive APFS."
diskutil info "$VOLUME" | grep -q "Encrypted:.*Yes" || check_fail "Not encrypted."

# 4. Free space
FREE_GB=$(df -g "$VOLUME" | tail -1 | awk '{print $4}')
(( FREE_GB < MIN_FREE_GB )) && check_fail "Free space too low: ${FREE_GB}GB (need >= ${MIN_FREE_GB}GB)"

check_ok "Volume $VOLUME is secure and ready."
echo "LAST_OK: $(date)" > "$SENTINEL"
check_ok "Sentinel file updated: $SENTINEL"
