set -euo pipefail
for f in manifest.json nova.core.manifest.json; do
  COSIGN_EXPERIMENTAL=1 cosign sign-blob --yes \
    --bundle "/Volumes/Workspace/.nova/manifests/$f.bundle" \
    --output-certificate "/Volumes/Workspace/.nova/manifests/$f.crt" \
    --output-signature "/Volumes/Workspace/.nova/manifests/$f.sig" \
    "/Volumes/Workspace/.nova/manifests/$f"
done
