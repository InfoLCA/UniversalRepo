# 🚀 NovaCore Secure Workspace — START HERE

This SSD volume **/Volumes/Workspace** is the single source of truth for NovaCore development.  
It has been hardened to **state-of-the-art engineering standards** (FAANG+ level) to guarantee determinism, security, and zero accidental drift.

---

## ✅ Guardrails Always Enforced

1. **Ownership**  
   - Volume owners: **Enabled**  
   - Checked + auto-fixed on every mount by a LaunchAgent.  

2. **Filesystem**  
   - APFS (Case-sensitive, Encrypted).  
   - Encryption password stored in macOS Keychain (`Workspace`).  

3. **Preflight Checks**  
   - Run with:  
     ```bash
     ncgo
     ```  
   - This executes **NovaGuard**:  
     - Ensures mountpoint exists.  
     - Confirms Owners: Enabled.  
     - Confirms Case-sensitive APFS.  
     - Confirms Encrypted: Yes.  
     - Ensures ≥10GB free.  
     - Updates sentinel + manifests.

4. **Sentinel File**  
   - `/Volumes/Workspace/.NOVACORE_OK` updated automatically.  
   - Must always exist; if missing → stop work immediately.

5. **Manifests**  
   - `manifest.json` and `nova.core.manifest.json` track file integrity.  
   - Updated automatically on each `ncgo` run.  
   - Append-only, never modify old entries.  

---

## 🟢 What “Good” Looks Like

Sample output from `ncgo`:

NovaCore Preflight (guardrails on)
✅ Volume present: /Volumes/Workspace
✅ Ownership: Enabled
✅ Filesystem: Case-sensitive APFS
✅ Encryption: Enabled
✅ Free space: 1800+GB (>= 10GB)

NovaCore Preflight Summary
• Volume UUID:    
• Filesystem:     Case-sensitive APFS
• Ownership:      Enabled
• Encryption:     Yes
• Size/Used:      
✅ All invariants satisfied. Ready.

---

## 🔴 If You See Red

- **❌ Owners not enabled** → re-run `ncgo`; if persists, check `/tmp/novaguard_agent.log`.  
- **❌ Not encrypted** → stop immediately; reformat required.  
- **❌ Free space too low** → free disk space before continuing.  
- **❌ Sentinel missing** → run `ncgo` to regenerate.  

Logs:  
```bash
cat /tmp/novaguard_agent.log

📌 Rules of Engagement
	•	Always start work by running ncgo.
	•	Never bypass NovaGuard.
	•	Never delete or overwrite manifests.
	•	If any invariant fails, fix it before making changes.
	•	Every new file must be appended to the manifest with its SHA-256.
	•	Optionally: sign manifests with Cosign/GPG for cryptographic attestation.
-------

# NovaCore Workspace

A clean, FAANG-style layout for a single-developer secure workspace with dynamic manifests, cosign verification, and guardrails.

## Directory Layout

/Volumes/Workspace/
├── manifest.json                 # Canonical project manifest (symlink target in .nova/)
├── nova.core.manifest.json       # Core/system manifest (symlink target in .nova/)
├── novaguard.sh                  # Entry-point guard script (preflight + cosign verify)
├── README.md                     # You are here
├── NOVACORE_GUARDRAILS.md        # Governance/security notes
└── .nova/                        # Hidden infra: keys, logs, manifests, archives
├── manifests/
│   ├── manifest.json -> /Volumes/Workspace/manifest.json
│   ├── nova.core.manifest.json -> /Volumes/Workspace/nova.core.manifest.json
│   ├── *.bundle / *.crt / *.sig
│   └── archive/YYYY-MM-DD/
├── logs/
│   └── novaguard.log
├── keys/                     # (development only) temporary local keys
├── scripts/                  # helper scripts (e.g., resign_manifests.sh)
└── sentinels/
└── .NOVACORE_OK (via root)

> **Canonical truth:** The two **root** manifests are the source of truth. The files in `.nova/manifests/` are symlinks to them.

---

## Daily Workflow

1. **Preflight & Verify**
   ```bash
   cd /Volumes/Workspace && ./novaguard.sh

Expected output: Signatures verified ✓.
	2.	Update dynamic manifests

/usr/local/bin/nova_manifest_update

This refreshes hashes for:
	•	/Volumes/Workspace/.NOVACORE_OK
	•	/Volumes/Workspace/README.md (or README-START-HERE.md if still present historically)

	3.	If manifests changed, re-sign (keyless)

# Sign each symlinked manifest in .nova/manifests/
COSIGN_EXPERIMENTAL=1 cosign sign-blob --yes \
  --bundle /Volumes/Workspace/.nova/manifests/manifest.json.bundle \
  --output-certificate /Volumes/Workspace/.nova/manifests/manifest.json.crt \
  --output-signature /Volumes/Workspace/.nova/manifests/manifest.json.sig \
  /Volumes/Workspace/.nova/manifests/manifest.json

COSIGN_EXPERIMENTAL=1 cosign sign-blob --yes \
  --bundle /Volumes/Workspace/.nova/manifests/nova.core.manifest.json.bundle \
  --output-certificate /Volumes/Workspace/.nova/manifests/nova.core.manifest.json.crt \
  --output-signature /Volumes/Workspace/.nova/manifests/nova.core.manifest.json.sig \
  /Volumes/Workspace/.nova/manifests/nova.core.manifest.json


	4.	Verify signatures (pinned identity)

COSIGN_EXPERIMENTAL=1 cosign verify-blob \
  --bundle /Volumes/Workspace/.nova/manifests/manifest.json.bundle \
  --certificate-identity-regexp 'info@legalcaseallies.com' \
  --certificate-oidc-issuer https://github.com/login/oauth \
  /Volumes/Workspace/.nova/manifests/manifest.json

COSIGN_EXPERIMENTAL=1 cosign verify-blob \
  --bundle /Volumes/Workspace/.nova/manifests/nova.core.manifest.json.bundle \
  --certificate-identity-regexp 'info@legalcaseallies.com' \
  --certificate-oidc-issuer https://github.com/login/oauth \
  /Volumes/Workspace/.nova/manifests/nova.core.manifest.json



⸻

Logs & Sentinels
	•	Log location (permanent):
Log lives at .nova/logs/novaguard.log. Keep a root symlink:

/Volumes/Workspace/novaguard.log -> /Volumes/Workspace/.nova/logs/novaguard.log

If the symlink disappears, recreate it.

	•	Sentinels:
	•	.NOVACORE_OK (required): updated every preflight run.
	•	.NOVACORE_OKncheck_ok (if present): harmless stray file; safe to delete. If it returns, file a task to patch the script.

⸻

Ephemeral macOS Files (will always reappear)

These folders are created by macOS on external/secondary volumes and do not affect NovaCore:
	•	.DocumentRevisions-V100/
	•	.Spotlight-V100/
	•	.TemporaryItems/
	•	.fseventsd/

Policy: never commit them; ignore or purge as needed.

.gitignore snippet

.DS_Store
.DocumentRevisions-V100
.Spotlight-V100
.TemporaryItems
.fseventsd
.nova/logs/
.nova/keys/
.nova/manifests/archive/


⸻

Time Format & Zone

nova_manifest_update writes:
	•	integrity.last_verified: YYYY-MM-DD hh:mm:ss AM/PM -04:00 (EDT, 12-hour clock)

This is intentional for human readability and local audit trail.

⸻

Quick Verification Checklist
	•	./novaguard.sh → Verified OK
	•	nova_manifest_update ran without errors
	•	manifest.json & nova.core.manifest.json are symlinked into .nova/manifests/
	•	novaguard.log is a symlink at root (targeting .nova/logs/novaguard.log)
	•	No stray .NOVACORE_OKncheck_ok file
	•	Root contains exactly 5 files:
	•	manifest.json, nova.core.manifest.json, novaguard.sh, README.md, NOVACORE_GUARDRAILS.md

⸻

Troubleshooting
	•	“invalid signature when validating ASN.1 encoded signature”
Re-sign both manifests (keyless) and verify again (see commands above).
	•	Root keeps showing novaguard.log as a regular file
Recreate the symlink and (optionally) rotate/append the old contents into .nova/logs/novaguard.log.
	•	Warnings about last_verified being older than sentinel
Run nova_manifest_update before verification or delay the sentinel write until after verification in your script.

⸻

Security Notes
	•	Development: keyless signing is preferred; if you must use files, keep them in .nova/keys/ with strict perms (700 for dir, 600 for private key).
	•	Production: use KMS/HSM or GitHub OIDC keyless signing—never commit persistent private keys.

---

# How to check if manifests are up to date (when you’re ready)

- Run:

/usr/local/bin/nova_manifest_update && 
grep -n ‘“last_verified”’ /Volumes/Workspace/manifest.json /Volumes/Workspace/nova.core.manifest.json

- If timestamps changed, re-sign and verify (commands are already in the README above).

---

If you want, I can also generate a tiny **`README.md` diff** instead of full replacement; but given the amount of new policy, the full drop-in above is cleaner.

System Folders (macOS Auto-Generated)

The following folders may appear automatically at the root of /Volumes/Workspace due to macOS behavior:
	•	.DocumentRevisions-V100
	•	.Spotlight-V100
	•	.fseventsd
	•	.TemporaryItems

Policy:
	1.	These folders are not part of NovaCore and must not remain at root.
	2.	Always move them into .nova/archive/<date>/ using sudo mv.

sudo mv /Volumes/Workspace/.DocumentRevisions-V100 /Volumes/Workspace/.nova/archive/<date>/
sudo mv /Volumes/Workspace/.Spotlight-V100 /Volumes/Workspace/.nova/archive/<date>/
sudo mv /Volumes/Workspace/.fseventsd /Volumes/Workspace/.nova/archive/<date>/
sudo mv /Volumes/Workspace/.TemporaryItems /Volumes/Workspace/.nova/archive/<date>/

	3.	Never delete outright — archiving preserves auditability.
	4.	NovaGuard ignores these automatically; they do not affect verification.

## macOS System Files

The following system-generated files and folders are **intentionally excluded** via `.gitignore`:

.DS_Store
.DocumentRevisions-V100
.fseventsd
.Spotlight-V100
.TemporaryItems

**Rationale**:
- These are created automatically by macOS for indexing, versioning, and temporary storage.  
- They have **no functional value** for NovaCore.  
- Excluding them ensures clean commits, reduces repository noise, and aligns with **FAANG-grade hygiene standards**.

If any of these appear at the root, they can be safely ignored or archived in `.nova/archive/` during cleanup.
