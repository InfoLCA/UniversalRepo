# Scripts  
This folder contains executable shell scripts that perform the SSD bootstrap operations.
