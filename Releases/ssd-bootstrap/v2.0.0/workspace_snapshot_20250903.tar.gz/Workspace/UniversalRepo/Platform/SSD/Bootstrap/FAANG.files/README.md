# FAANG.files  
This folder mirrors state-of-the-art hygiene (Google/Netflix/Microsoft). It lists approved file trees and reference patterns.
