# Configs  
This folder holds configuration files (YAML/JSON/TOML) for customizing the SSD bootstrap behavior.
