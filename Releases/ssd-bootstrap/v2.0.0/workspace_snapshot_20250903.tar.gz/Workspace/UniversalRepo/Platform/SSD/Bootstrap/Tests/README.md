# Tests  
This folder contains validation scripts and checks to ensure the SSD bootstrap runs correctly.
