# Security Policy

NovaCore AI follows a “secure-by-default” posture with supply-chain transparency and responsible disclosure.

## Supported Versions
- Actively supported: `main` and the latest released tag.
- For `0.x` series: security fixes land on `main`; critical fixes may be backported to the latest release tag.

## Reporting a Vulnerability
- **Preferred:** GitHub Security Advisory → Security → “Report a vulnerability”
  https://github.com/InfoLCA/NovaCore.AI.CustomAgent/security/advisories/new
- **Do not open public issues** for vulnerabilities.
- Include: affected version/commit, reproduction steps, impact, and proposed CVSS if known.
- We acknowledge within **3 business days** and provide a fix/mitigation plan within **14 days** for High/Critical (CVSS ≥ 7.0).

## Coordinated Disclosure
- We aim to release a fix and coordinated advisory within **30–90 days**, depending on severity and exploitability.
- Credit is given to reporters who request it.

## Supply-Chain & Build Integrity
- **SBOM:** generated with Syft/Trivy on every build; stored under `security/sboms/`.
- **Signing/Provenance:** release images/artifacts are signed using **Sigstore Cosign (keyless)**; SLSA-style provenance (attestations) go to `security/attestations/`.
- **Policies:** runtime and admission policies live in `security/policies/` (OPA/Rego).
- **Reproducibility:** Nix flake (`flake.nix`) pins toolchains; CI enforces deterministic builds.

## Runtime Hardening (baseline)
- Minimal container privileges (no root where possible), read-only FS, least-privilege tokens.
- Egress allow-listing for LLM/providers; secrets via environment/secret stores only.
- Telemetry sanitization to avoid sensitive data in logs/traces.

## Contact
If GitHub advisories are unavailable, contact maintainers via repository owners or create a **private** security contact in your fork/organization.

---

## SBOM & Signing

NovaCore.AI produces a **CycloneDX SBOM** for every build and signs it with **Cosign** in keyless mode.

- Local generation: `./scripts/sbom-sign.sh`
- Outputs:
  - `security/sboms/syft_sbom.json`
  - `security/attestations/cosign_signatures/syft_sbom.sig`
  - `security/attestations/cosign_signatures/syft_sbom.crt`
  - `security/attestations/cosign_signatures/syft_sbom.bundle`

### Verification
```bash
cosign verify-blob \
  --bundle security/attestations/cosign_signatures/syft_sbom.bundle \
  --signature security/attestations/cosign_signatures/syft_sbom.sig \
  --certificate-identity "info@legalcaseallies.com" \
  --certificate-oidc-issuer "https://github.com/login/oauth" \
  security/sboms/syft_sbom.json
