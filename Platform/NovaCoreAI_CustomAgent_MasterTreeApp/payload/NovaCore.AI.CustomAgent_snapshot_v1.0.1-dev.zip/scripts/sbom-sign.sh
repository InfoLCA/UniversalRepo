#!/usr/bin/env bash
set -euo pipefail

SBOM="security/sboms/syft_sbom.json"
SIG="security/attestations/cosign_signatures/syft_sbom.sig"
CERT="security/attestations/cosign_signatures/syft_sbom.crt"
BUNDLE="security/attestations/cosign_signatures/syft_sbom.bundle"

mkdir -p "$(dirname "$SBOM")" "$(dirname "$SIG")"

need() { command -v "$1" >/dev/null 2>&1 || { echo "Missing $1. Install it (e.g., brew install $1)"; exit 127; }; }

need syft
need cosign

echo "Generating CycloneDX SBOM with syft → $SBOM"
syft . -o cyclonedx-json > "$SBOM"

echo "Keyless-signing SBOM with Cosign → $SIG (and cert+bundle)"
export COSIGN_EXPERIMENTAL=1
cosign sign-blob --yes \
  --output-signature "$SIG" \
  --output-certificate "$CERT" \
  --bundle "$BUNDLE" \
  "$SBOM"

echo "Done."
echo "SBOM:       $SBOM"
echo "Signature:  $SIG"
echo "Certificate:$CERT"
echo "Bundle:     $BUNDLE"
