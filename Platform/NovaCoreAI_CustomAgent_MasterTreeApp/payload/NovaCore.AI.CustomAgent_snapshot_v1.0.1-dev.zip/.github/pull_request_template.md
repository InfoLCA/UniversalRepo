## Description
<!-- What does this PR do? -->

## Checklist
- [ ] Tests added/updated
- [ ] Pre-commit hooks passed (`black`, `ruff`)
- [ ] Security considerations reviewed
- [ ] Linked to issue (if applicable)

## Reviewer Notes
<!-- Anything specific reviewers should focus on -->

