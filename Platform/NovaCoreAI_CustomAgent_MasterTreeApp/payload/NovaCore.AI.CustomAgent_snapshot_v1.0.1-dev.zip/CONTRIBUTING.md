# Contributing to NovaCore.AI

We welcome contributions! Please follow these guidelines:

## Workflow
- Fork the repo and create feature branches from `main`.
- Use [Conventional Commits](https://www.conventionalcommits.org/) for commit messages.
- Open a Pull Request with clear description and link to related issues.

## Code Style
- Python code is formatted with **Black** and linted with **Ruff**.
- Keep functions small and testable.
- Add/update type hints (`mypy`-friendly).

## Tests
- Write unit tests in `tests/unit/`.
- Write integration tests in `tests/integration/`.
- Run all tests with `pytest -q` before PR.

## Security
- Never commit secrets.
- SBOM + cosign signing must pass in CI (`security-build.yml`).

---

Thank you for contributing to **NovaCore.AI.CustomAgent**!
