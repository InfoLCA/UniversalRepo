"""Adapters and helpers shared by agents (stubs)."""
