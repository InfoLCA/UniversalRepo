"""Shared agent infrastructure."""
