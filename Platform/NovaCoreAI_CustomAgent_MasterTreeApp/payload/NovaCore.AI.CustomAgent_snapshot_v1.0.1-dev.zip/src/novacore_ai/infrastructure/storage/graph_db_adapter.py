class GraphDBAdapter:
    def put(self, node, props):
        return True

    def get(self, node):
        return {}
