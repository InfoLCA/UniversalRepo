def audit(event: str, **kw):
    return {"event": event, **kw}  # stub
