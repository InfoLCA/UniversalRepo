def encrypt(b: bytes) -> bytes:
    return b  # stub


def decrypt(b: bytes) -> bytes:
    return b  # stub
