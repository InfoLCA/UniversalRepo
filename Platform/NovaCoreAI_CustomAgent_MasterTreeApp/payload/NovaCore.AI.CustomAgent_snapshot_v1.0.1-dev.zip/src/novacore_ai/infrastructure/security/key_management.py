def get_key(alias: str) -> str:
    return f"key:{alias}"  # stub
