"""NovaCore AI package."""
