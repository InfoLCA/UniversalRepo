"""NovaCore kernel package."""
