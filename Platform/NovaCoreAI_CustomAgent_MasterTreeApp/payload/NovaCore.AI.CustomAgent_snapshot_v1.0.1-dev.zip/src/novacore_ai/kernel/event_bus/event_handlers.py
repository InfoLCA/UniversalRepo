from .message_broker import Event


def log_event(e: Event) -> None:
    # placeholder; will be wired to Telemetry later
    pass
