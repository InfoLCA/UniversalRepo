# Security Hardening

- Least-privilege tokens; rotate regularly.
- Network: default deny; allowlist egress to providers.
- SBOM gate (Syft/Trivy) + keyless signing (Cosign).
- OPA policies for capability admission.
- Audit logs for sensitive actions; ship to SIEM.
