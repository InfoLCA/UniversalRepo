# Local Setup

## Prereqs
- Python 3.13, make, git
- Optional: Docker, DVC

## Steps
1. `python -m venv .venv && source .venv/bin/activate`
2. `pip install -r requirements.txt` (or `pip install -e .[dev]`)
3. `pre-commit install`
4. `pytest -q`

## Run (dev)
- `uvicorn src.novacore_ai.api:app --reload`
- `docker compose up` for full stack (if needed)

## Env
Copy `.env.example` to `.env` and set provider keys.
