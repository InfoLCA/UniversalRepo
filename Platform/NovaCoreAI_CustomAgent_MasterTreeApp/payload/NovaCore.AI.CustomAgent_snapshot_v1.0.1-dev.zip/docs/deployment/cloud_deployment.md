# Cloud Deployment

## Build & Push
- `docker build -t <registry>/novacore:TAG .`
- `docker push <registry>/novacore:TAG`

## Runtime Options
- Container platform or Kubernetes (Deployment + Service).
- Supply secrets via KMS/Secret Manager.
- Expose Prometheus scrape endpoint; ship traces to Jaeger/Tempo.

## GitOps
- Immutable tags, SBOM + Cosign signatures (see SECURITY.md and workflow).
