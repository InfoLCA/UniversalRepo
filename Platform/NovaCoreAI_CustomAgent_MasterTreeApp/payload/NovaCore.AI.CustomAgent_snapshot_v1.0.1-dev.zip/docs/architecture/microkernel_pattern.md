# Microkernel Pattern

## Why
Keep the core minimal; move variability to plugins.

## Core
- Registry, event bus, security guardrails, telemetry contracts.

## Plugins
- Capabilities and providers; hot-swappable; discoverable via registry.

## Trade-offs
+ Extensibility, testability
− Slight indirection cost; needs good contracts & observability
