# Architecture Overview

This section is the canonical map of NovaCore AI’s architecture.

## Principles
- Microkernel + plugins (capabilities/providers).
- Strict boundaries, DI over concrete deps.
- Observability and security baked in.

## Module Map
- **Kernel**: registry, interfaces, event bus, security.
- **Capabilities**: reasoning, memory, execution, communication, audit.
- **Infrastructure**: providers, storage, security, telemetry.

## Diagram
See `docs/architecture/diagram.png` (added in step 2/8) and the root README for an embedded view.

## Contracts
- Capability interface: init → handle → teardown
- Provider interface: configure → call → metrics
- Telemetry interface: emit → export
