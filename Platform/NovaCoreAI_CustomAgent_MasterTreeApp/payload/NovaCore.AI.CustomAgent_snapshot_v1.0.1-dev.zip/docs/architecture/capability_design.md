# Capability Design

## Contract
- `init(config, registry)`, `handle(message|task)`, `teardown()`.

## Lifecycle
1. Registered in kernel registry.
2. Constructed with config and shared services.
3. Invoked by agents; emits telemetry.

## Testing
- Unit: pure logic in `/lib`.
- Contract: behaviors via interface mocks.
- E2E: agent workflow with one real capability.

## Versioning
Semver per capability; breaking changes bump major and update registry.
