# Clean Architecture

## Layers
- **Interfaces (Kernel)**: stable contracts, no domain logic.
- **Capabilities (Use Cases)**: pure application logic via contracts.
- **Infrastructure (Adapters)**: I/O, providers, storage, telemetry.

## Dependency Rule
Inner layers know nothing about outer ones. Flow: Interfaces → Capabilities → Infrastructure (via ports).

## Data Flow
Request → Agent → Capability (use case) → Provider/Store (adapter) → Response.
